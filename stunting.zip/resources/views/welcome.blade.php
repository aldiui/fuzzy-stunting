 <table>
     <tr>
         <td>Usia</td>
         <td>Jenis Kelamin</td>
         <td>Berat Badan</td>
         <td>Tinggi Badan</td>
     </tr>
     <tr>
         <td>{{ $jenisKelamin }}</td>
         <td>{{ $beratBadan }}</td>
         <td>{{ $usia }}</td>
         <td>{{ $tinggiBadan }}</td>
     </tr>
 </table>

 {{ $variabelFuzzy }}
