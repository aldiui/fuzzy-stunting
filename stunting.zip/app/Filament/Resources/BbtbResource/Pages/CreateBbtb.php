<?php

namespace App\Filament\Resources\BbtbResource\Pages;

use App\Filament\Resources\BbtbResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBbtb extends CreateRecord
{
    protected static string $resource = BbtbResource::class;
}
