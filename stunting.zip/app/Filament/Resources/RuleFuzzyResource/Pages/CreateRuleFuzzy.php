<?php

namespace App\Filament\Resources\RuleFuzzyResource\Pages;

use App\Filament\Resources\RuleFuzzyResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRuleFuzzy extends CreateRecord
{
    protected static string $resource = RuleFuzzyResource::class;
}
