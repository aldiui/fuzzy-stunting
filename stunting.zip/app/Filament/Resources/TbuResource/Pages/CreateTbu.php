<?php

namespace App\Filament\Resources\TbuResource\Pages;

use App\Filament\Resources\TbuResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTbu extends CreateRecord
{
    protected static string $resource = TbuResource::class;
}
