<div class="flex items-center justify-center gap-x-3 dark:bg-gray-800">
    <div class="whitespace-nowrap">
        <div class="text-sm text-center font-bold text-gray-600 dark:text-white">CERDAS</div>
        <div class="text-xs font-semibold text-gray-400 dark:text-white">Cegah Stunting dengan Deteksi Awal Sehat</div>
    </div>
</div>
<?php /**PATH E:\proyek\stunting\resources\views/logo.blade.php ENDPATH**/ ?>