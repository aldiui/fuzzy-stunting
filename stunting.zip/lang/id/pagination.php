<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan oleh perpustakaan paginator untuk membangun
    | tautan pagination sederhana. Anda bebas mengubahnya menjadi apapun
    | yang Anda inginkan untuk menyesuaikan tampilan Anda agar sesuai dengan aplikasi Anda.
    |
     */

    'previous' => '&laquo; Sebelumnya',
    'next' => 'Berikutnya &raquo;',

];
